import { Monitor, Instagram, Twitter, Linkedin, Facebook } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-50 border-t border-slate-200 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <Monitor className="h-8 w-8 text-purple-600" />
              <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">Lumina Tech</span>
            </div>
            <p className="text-slate-500 leading-relaxed">
              We empower businesses through innovative technology and creative excellence, delivering solutions that inspire growth and success.
            </p>
            <div className="flex space-x-4">
              {[Twitter, Instagram, Linkedin, Facebook].map((Icon, idx) => (
                <a key={idx} href="#" className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-purple-600 hover:border-purple-200 hover:shadow-lg hover:shadow-purple-100 transition-all">
                  <Icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold text-slate-900 mb-6 uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-4">
              {['About Us', 'Our Services', 'Recent Projects', 'Contact Info', 'Privacy Policy'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-purple-600 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-bold text-slate-900 mb-6 uppercase tracking-wider">Services</h4>
            <ul className="space-y-4">
              {['Web Design', 'App Development', 'Digital Marketing', 'Cloud Solutions', 'Cyber Security'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-purple-600 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-lg font-bold text-slate-900 mb-6 uppercase tracking-wider">Newsletter</h4>
            <p className="text-slate-500 mb-6">Stay updated with our latest insights and news.</p>
            <form className="space-y-3">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent transition-all shadow-sm"
              />
              <button className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-lg shadow-purple-200 transition-all">
                Subscribe Now
              </button>
            </form>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center text-slate-400 text-sm">
          <p>© 2024 Lumina Tech. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-purple-600 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-purple-600 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-purple-600 transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
