import { motion } from 'framer-motion';
import { Laptop, Database, PenTool, Layout, Layers, ShieldCheck } from 'lucide-react';

const services = [
  {
    icon: <Layout className="h-10 w-10 text-purple-600" />,
    title: 'Modern UI/UX Design',
    description: 'We create intuitive, visually stunning interfaces that provide seamless user experiences across all devices.',
    color: 'bg-purple-100/50'
  },
  {
    icon: <Laptop className="h-10 w-10 text-indigo-600" />,
    title: 'Responsive Development',
    description: 'Custom-built web applications using the latest technologies like React, Vite, and Tailwind CSS.',
    color: 'bg-indigo-100/50'
  },
  {
    icon: <Database className="h-10 w-10 text-blue-600" />,
    title: 'Cloud Infrastructure',
    description: 'Scalable and secure cloud solutions that ensure your business is always online and performing at its best.',
    color: 'bg-blue-100/50'
  },
  {
    icon: <PenTool className="h-10 w-10 text-pink-600" />,
    title: 'Creative Branding',
    description: 'Developing unique brand identities that resonate with your target audience and stand out in the market.',
    color: 'bg-pink-100/50'
  },
  {
    icon: <Layers className="h-10 w-10 text-emerald-600" />,
    title: 'SEO & Marketing',
    description: 'Data-driven marketing strategies to increase your visibility and reach new customers globally.',
    color: 'bg-emerald-100/50'
  },
  {
    icon: <ShieldCheck className="h-10 w-10 text-amber-600" />,
    title: 'Cyber Security',
    description: 'Protecting your digital assets with advanced security protocols and continuous monitoring.',
    color: 'bg-amber-100/50'
  }
];

const Services = () => {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-purple-600 font-bold tracking-widest uppercase text-sm"
          >
            Our Services
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-extrabold text-slate-900"
          >
            Empowering Your <span className="gradient-text">Business</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-slate-500 max-w-2xl mx-auto"
          >
            We provide a comprehensive suite of digital services designed to take your business to the next level of innovation.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="p-10 rounded-3xl bg-slate-50 hover:bg-white hover:shadow-2xl hover:shadow-purple-100 border border-slate-100 transition-all duration-300 group"
            >
              <div className={`w-20 h-20 rounded-2xl ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                {service.icon}
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-4">{service.title}</h3>
              <p className="text-slate-600 leading-relaxed">
                {service.description}
              </p>
              <button className="mt-8 flex items-center text-purple-600 font-bold group-hover:translate-x-2 transition-transform">
                Learn more <span className="ml-2">→</span>
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
