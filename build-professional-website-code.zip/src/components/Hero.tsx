import { motion } from 'framer-motion';
import { ChevronRight, Play, Zap, Shield, Sparkles } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 md:pt-48 md:pb-32 bg-slate-50">
      {/* Decorative Blur Spheres */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-200/50 rounded-full blur-3xl -z-10 animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-200/50 rounded-full blur-3xl -z-10 animate-pulse delay-1000" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Content */}
          <div className="lg:w-1/2 space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center space-x-2 px-3 py-1 bg-purple-100/50 border border-purple-200 rounded-full"
            >
              <Sparkles className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-semibold text-purple-700">Digital Solutions for Tomorrow</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-5xl md:text-7xl font-extrabold text-slate-900 tracking-tight leading-[1.1]"
            >
              Building the Future of <span className="gradient-text">Professional</span> Excellence.
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-slate-600 leading-relaxed max-w-xl"
            >
              Lumina Tech delivers cutting-edge creative and technical solutions that help businesses scale with style and efficiency.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <button className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-purple-200 transition-all hover:scale-[1.02] flex items-center justify-center">
                Get Started Now <ChevronRight className="ml-2 h-5 w-5" />
              </button>
              <button className="bg-white hover:bg-slate-50 text-slate-900 border border-slate-200 px-8 py-4 rounded-2xl font-bold transition-all hover:scale-[1.02] flex items-center justify-center">
                <Play className="mr-2 h-5 w-5 fill-purple-600 text-purple-600" /> Watch Demo
              </button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="pt-8 flex items-center space-x-8 text-slate-400"
            >
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5" />
                <span className="text-sm font-medium">Lightning Fast</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="h-5 w-5" />
                <span className="text-sm font-medium">Enterprise Security</span>
              </div>
            </motion.div>
          </div>

          {/* Visual - Inspired by the laptop image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, rotateY: 20 }}
            animate={{ opacity: 1, scale: 1, rotateY: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="lg:w-1/2 relative flex justify-center perspective-1000"
          >
            <div className="relative z-10 p-4 bg-slate-900/10 rounded-3xl border border-white/40 shadow-2xl backdrop-blur-xl">
              <img
                src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=1200"
                alt="Technology Preview"
                className="rounded-2xl shadow-xl w-full max-w-[600px] object-cover"
              />
              {/* Floating Element 1 - Inspired by the flower */}
              <div className="absolute -top-10 -right-10 glass p-6 rounded-3xl shadow-xl animate-bounce duration-[3000ms]">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-2">
                  <Sparkles className="h-6 w-6 text-purple-600" />
                </div>
                <div className="text-xs font-bold text-slate-800">Vibrant Design</div>
              </div>
              {/* Floating Element 2 */}
              <div className="absolute -bottom-10 -left-10 dark-glass p-6 rounded-3xl shadow-xl animate-pulse">
                <div className="text-white font-bold mb-1 flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <span>Systems Online</span>
                </div>
                <div className="text-indigo-200 text-xs">Uptime 99.99%</div>
              </div>
            </div>
            
            {/* Background Glow */}
            <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 to-indigo-500/20 blur-2xl rounded-full" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
