import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, Instagram, Twitter, Linkedin } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-slate-900 text-white overflow-hidden relative">
      {/* Background Decorative Blur */}
      <div className="absolute top-1/4 -right-24 w-96 h-96 bg-purple-600/20 rounded-full blur-[120px]" />
      <div className="absolute bottom-1/4 -left-24 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row gap-16 items-start">
          {/* Info Side */}
          <div className="lg:w-1/2 space-y-12">
            <div className="space-y-6">
              <motion.h2
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="text-4xl md:text-5xl font-extrabold"
              >
                Let's <span className="text-purple-400">Connect</span> & Build Something Great.
              </motion.h2>
              <motion.p
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="text-xl text-slate-400 max-w-lg leading-relaxed"
              >
                Ready to take your business to the next level? Our team of experts is here to help you navigate the digital landscape.
              </motion.p>
            </div>

            <div className="space-y-8">
              {[
                { icon: <Mail className="h-6 w-6" />, label: 'Email Us', val: 'hello@lumina-tech.com' },
                { icon: <Phone className="h-6 w-6" />, label: 'Call Us', val: '+1 (555) 000-0000' },
                { icon: <MapPin className="h-6 w-6" />, label: 'Visit Us', val: '123 Tech Avenue, Silicon Valley, CA' },
              ].map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 + 0.2 }}
                  className="flex items-center space-x-4 p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                >
                  <div className="w-12 h-12 rounded-full bg-purple-600/20 flex items-center justify-center text-purple-400">
                    {item.icon}
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">{item.label}</div>
                    <div className="text-lg font-medium">{item.val}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="flex space-x-6">
              {[Instagram, Twitter, Linkedin].map((Icon, idx) => (
                <a key={idx} href="#" className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-purple-600 transition-all transform hover:scale-110">
                  <Icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Form Side */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="lg:w-1/2 w-full p-8 md:p-12 rounded-3xl bg-white text-slate-900 shadow-2xl"
          >
            <h3 className="text-2xl font-bold mb-8">Send us a Message</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-500 uppercase">First Name</label>
                  <input type="text" placeholder="John" className="w-full px-6 py-4 rounded-xl bg-slate-100 border-none focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-500 uppercase">Last Name</label>
                  <input type="text" placeholder="Doe" className="w-full px-6 py-4 rounded-xl bg-slate-100 border-none focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-500 uppercase">Email Address</label>
                <input type="email" placeholder="john@example.com" className="w-full px-6 py-4 rounded-xl bg-slate-100 border-none focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-500 uppercase">Message</label>
                <textarea rows={4} placeholder="How can we help you?" className="w-full px-6 py-4 rounded-xl bg-slate-100 border-none focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all resize-none"></textarea>
              </div>
              <button className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-lg shadow-purple-200 flex items-center justify-center space-x-2 transition-all transform hover:translate-y-[-2px]">
                <span>Send Message</span>
                <Send className="h-5 w-5" />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
