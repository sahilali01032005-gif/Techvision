import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-slate-50 selection:bg-purple-200 selection:text-purple-900">
      <Navbar />
      <main>
        <Hero />
        
        {/* Trusted By Section */}
        <section className="py-12 bg-white border-y border-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p className="text-sm font-bold text-slate-400 uppercase tracking-[0.2em] mb-8">Trusted by industry leaders worldwide</p>
            <div className="flex flex-wrap justify-center gap-12 md:gap-20 opacity-40 grayscale hover:grayscale-0 transition-all">
              {['Microsoft', 'Apple', 'Google', 'Amazon', 'Adobe'].map((company) => (
                <span key={company} className="text-2xl font-black text-slate-900 tracking-tighter">{company}</span>
              ))}
            </div>
          </div>
        </section>

        <Services />

        {/* Call to Action Section */}
        <section className="py-24 bg-gradient-to-br from-purple-600 to-indigo-700 relative overflow-hidden">
          <div className="absolute inset-0 bg-grid-white/[0.1] -z-0" />
          <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
            <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-8">
              Transform Your Digital Future Today
            </h2>
            <p className="text-xl text-purple-100 mb-10 leading-relaxed">
              Join hundreds of companies that have scaled their operations and improved their brand presence with our expert solutions.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <button className="px-10 py-5 bg-white text-purple-700 font-bold rounded-2xl shadow-xl hover:bg-slate-50 transition-all transform hover:scale-105">
                Book a Free Strategy Call
              </button>
              <button className="px-10 py-5 bg-purple-500/20 border border-white/30 text-white font-bold rounded-2xl backdrop-blur-sm hover:bg-purple-500/30 transition-all">
                View Pricing
              </button>
            </div>
          </div>
        </section>

        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
